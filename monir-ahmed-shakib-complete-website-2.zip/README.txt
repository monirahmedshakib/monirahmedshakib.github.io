Monir Ahmed Shakib Website — Complete Demo

এই ভার্সনে:
- Personal website
- আপনার ছবি
- Home/About/Services/Portfolio/Blog/Contact
- Mobile responsive
- Admin Login
- Add/Edit/Delete
- About ও Contact Update
- Browser localStorage-এ data save

Admin demo:
Username: admin
Password: 123456

গুরুত্বপূর্ণ:
এটি একটি client-side demo Admin Panel। সত্যিকারের নিরাপদ online admin/database system করতে hosting + backend + server-side authentication লাগবে। এই ZIP browser/HTML editor-এ খুলে পরীক্ষা করা যাবে।
